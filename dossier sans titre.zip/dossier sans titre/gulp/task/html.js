var gulp        = require('gulp'),
    browserSync = require('browser-sync');

gulp.task('html', function () {
    browserSync.reload();
});