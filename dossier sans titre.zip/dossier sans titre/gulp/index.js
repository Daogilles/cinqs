var requireDir = require('require-dir');

requireDir('./task',  {recurse: true});